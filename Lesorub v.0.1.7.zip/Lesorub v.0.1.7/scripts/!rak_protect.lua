--[[

Author: _razor. Version: 1.2 Thanks: Ulong

<3

]]


local utils = require("samp.events.utils")
require("sampfuncs")
require("addon")
math.randomseed(os.clock())

local function random_float(lower, greater)
	return lower + math.random() * (greater - lower)
end

local protects = {
    aim = {
        bot_move = true,
        last_rate_time = os.time() + math.random(10, 60),
        last_pos = {
            x = 0.0, 
            y = 0.0, 
            z = 0.0
        },
        z_cam = math.random(0, 1) == 0 and random_float(-0.1, -0.2) or random_float(0.1, 0.2),
        sync_rate = 8
    },
    ping = {
        update = false,
        key_action = false,
        next_update_time = os.time()
    },
    weapon = {
        bot_gun = {
            current_weapon = 0,
            wdata = {
                [0] = {weapon = 0, ammo = 0},
                [1] = {weapon = 0, ammo = 0},
                [2] = {weapon = 0, ammo = 0},
                [3] = {weapon = 0, ammo = 0},
                [4] = {weapon = 0, ammo = 0},
                [5] = {weapon = 0, ammo = 0},
                [6] = {weapon = 0, ammo = 0},
                [7] = {weapon = 0, ammo = 0},
                [8] = {weapon = 0, ammo = 0},
                [9] = {weapon = 0, ammo = 0},
                [10] = {weapon = 0, ammo = 0},
                [11] = {weapon = 0, ammo = 0},
                [12] = {weapon = 0, ammo = 0}
            }
        },
        e_WEAPON_STATES = {
            [16] = 1, [17] = 1, [18] = 1, [22] = 2, [23] = 2,
            [24] = 2, [25] = 1, [26] = 2, [27] = 2, [28] = 2,
            [29] = 2, [30] = 2, [31] = 2, [32] = 2, [33] = 1,
            [34] = 1 ,[35] = 1, [36] = 1, [37] = 2, [38] = 2,
            [39] = 1, [40] = 1, [41] = 2, [42] = 2, [43] = 2
        },
        e_WEAPON_SLOTS = {
            [0] = 0, [1] = 0, [2] = 1, [3] = 1, [4] = 1, 
            [5] = 1, [6] = 1, [7] = 1, [8] = 1, [9] = 1, 
            [10] = 10, [11] = 10, [12] = 10, [13] = 10, [14] = 10, 
            [15] = 10, [16] = 8, [17] = 8, [18] = 8,[22] = 2, 
            [23] = 2, [24] = 2, [25] = 3, [26] = 3, [27] = 3,
            [28] = 4, [29] = 4, [30] = 5, [31] = 5, [32] = 4, 
            [33] = 6, [34] = 6, [35] = 7, [36] = 7,[37] = 7, 
            [38] = 7, [39] = 8, [40] = 12, [41] = 9, [42] = 9, 
            [43] = 9, [44] = 11, [45] = 11, [46] = 11
        }
    },
    client_check = {
        emulate_running_time = os.clock() + random_float(1800.0, 43200.0),
        generated_models_hashes = {},
        generated_cols_hashes = {}
    }
}

local function getCurrentUsedWeapon() return protects.weapon.bot_gun.current_weapon end
local function getCurrentWeaponState() return protects.weapon.e_WEAPON_STATES[protects.weapon.bot_gun.current_weapon] ~= nil and protects.weapon.e_WEAPON_STATES[protects.weapon.bot_gun.current_weapon] or 0 end
local function updateCurrentWeapon(weaponId) protects.weapon.bot_gun.current_weapon = weaponId end
local function updateSlotInfo(slot, weaponId, ammo)
	protects.weapon.bot_gun.wdata[slot].ammo = protects.weapon.bot_gun.wdata[slot].weapon ~= weaponId and ammo or protects.weapon.bot_gun.wdata[slot].ammo + ammo
	protects.weapon.bot_gun.wdata[slot].weapon = weaponId
end
local function getGunSlotByWeaponId(weaponId)
    for weapon, slot in pairs(protects.weapon.e_WEAPON_SLOTS) do
        if weapon == weaponId then
            return slot
        end
    end
	return nil
end
local function sendWeaponsUpdate()
	local bs = bitStream.new()
	bs:writeUInt8(PACKET_WEAPONS_UPDATE)	
	bs:writeUInt16(65535)
	bs:writeUInt16(65535)
	for i = 0, #protects.weapon.bot_gun.wdata do
		bs:writeUInt8(i)
		bs:writeUInt8(protects.weapon.bot_gun.wdata[i].weapon)
		bs:writeUInt16(protects.weapon.bot_gun.wdata[i].ammo)
	end
	bs:sendPacket()
	bs:reset()
end
local function addWeapon(weaponId, ammo)
	local slot = getGunSlotByWeaponId(weaponId)
	if slot ~= nil then
		updateSlotInfo(slot, weaponId, ammo)
		updateCurrentWeapon(weaponId)
		sendWeaponsUpdate()
	end
end
local function setAmmo(weaponId, ammo)
	local slot = getGunSlotByWeaponId(weaponId)
	if slot ~= nil then
		protects.weapon.bot_gun.wdata[slot].weapon = 0
		updateSlotInfo(slot, weaponId, ammo)
		sendWeaponsUpdate()
	end
end
local function resetWeapons()
	protects.weapon.bot_gun.current_weapon = 0
	for i = 0, #protects.weapon.bot_gun.wdata do
		protects.weapon.bot_gun.wdata[i] = {weapon = 0, ammo = 0}
	end
end

local function sendClientCheckResponse(requestType, result1, result2)
    local bs = bitStream.new()
    bs:writeUInt8(requestType)
    bs:writeUInt32(result1)
    bs:writeUInt8(result2)
    bs:sendRPC(RPC_CLIENTCHECK)
end

local function sendUpdateScoresAndPings()
	local bs = bitStream.new()
	bs:sendRPC(RPC_UPDATESCORESPINGSIPS)
end

registerHandler("onLoad", function()
    setRate(protects.aim.sync_rate, 1000)
end)

registerHandler("onSendPacket", function(id, bs)
	if id == PACKET_AIM_SYNC then
		if not protects.aim.bot_move then
			if isBotSpawned() then
				if protects.aim.last_rate_time < os.time() then
					protects.aim.last_rate_time = os.time() + math.random(10, 60)
					local aim_data = (utils.process_outcoming_sync_data(bs, 'AimSyncData'))[1]
					aim_data.camMode = getBotVehicle() ~= 0 and 18 or 4
					aim_data.camExtZoom = 63
					aim_data.camFront.z = protects.aim.z_cam
                    aim_data.weaponState = getCurrentWeaponState()
				else
					return false
				end
			else
				return false
			end
		else
			protects.aim.bot_move = false
			return false
		end
	end
	if id == PACKET_PLAYER_SYNC or id == PACKET_VEHICLE_SYNC then
		local data = id == PACKET_PLAYER_SYNC and (utils.process_outcoming_sync_data(bs, 'PlayerSyncData'))[1] or (utils.process_outcoming_sync_data(bs, 'VehicleSyncData'))[1]

		if data.position.x ~= protects.aim.last_pos.x or data.position.y ~= protects.aim.last_pos.y or data.position.z ~= protects.aim.last_pos.z then
			protects.aim.bot_move = true
		end

		protects.aim.last_pos = {x = data.position.x, y = data.position.y, z = data.position.z}

        if protects.ping.update then
            protects.ping.key_action = false
            protects.ping.update = false
            protects.ping.next_update_time = os.time() + math.random(10, 120)
            sendUpdateScoresAndPings()
        end

        if protects.ping.key_action then
            data.keysData = data.keysData + 1
            protects.ping.update = true
        end

        if id == PACKET_PLAYER_SYNC then
            data.weapon = getCurrentUsedWeapon()
        end

        if id == PACKET_VEHICLE_SYNC then
            data.currentWeapon = getCurrentUsedWeapon()
        end
	end

    if id == PACKET_SPECTATOR_SYNC or id == PACKET_PASSENGER_SYNC then
        if protects.ping.key_action then
			protects.ping.key_action = false
			protects.ping.next_update_time = os.time() + math.random(3, 10)
			sendUpdateScoresAndPings()
		end
    end
end)

registerHandler("onReceivePacket", function(id, bs)
    if id == PACKET_DISCONNECTION_NOTIFICATION or id == PACKET_CONNECTION_LOST or id == PACKET_CONNECTION_BANNED or id == PACKET_INVALID_PASSWORD then
        resetWeapons()
    end
end)

registerHandler("onSendRPC", function(id, bs) 
    if id == RPC_UPDATESCORESPINGSIPS then
		if protects.ping.next_update_time < os.time() then
			protects.ping.key_action = true
		end
		return false
	end
end)

registerHandler("onReceiveRPC", function(id, bs)
	if id == RPC_SCRSETPLAYERPOS or id == RPC_SCRSETPLAYERPOSFINDZ then -- send aim sync when setplayerpos
		local pos = {}
		pos.x = bs:readFloat()
		pos.y = bs:readFloat()
		pos.z = bs:readFloat()
		protects.aim.last_pos = {x = pos.x, y = pos.y, z = pos.z}
		protects.aim.last_rate_time = os.time() - 1
	end

    if id == RPC_CLIENTCHECK then
        local request_type = bs:readUInt8()
        local subject = bs:readUInt32()
        local offset = bs:readUInt16()
        local len = bs:readUInt16()

        if request_type == 0x48 then -- computer running
            local current_time = protects.client_check.emulate_running_time + os.clock()
            sendClientCheckResponse(request_type, current_time, 0)
        elseif request_type == 0x46 then -- fake checksum for model and col
            if not protects.client_check.generated_models_hashes[subject] then
                protects.client_check.generated_models_hashes[subject] = math.random(1, 255)
            end
            sendClientCheckResponse(request_type, protects.client_check.generated_models_hashes[subject], 0)
        elseif request_type == 0x47 then
            if not protects.client_check.generated_cols_hashes[subject] then
                protects.client_check.generated_cols_hashes[subject] = math.random(1, 255)
            end
            sendClientCheckResponse(request_type, protects.client_check.generated_cols_hashes[subject], 0)
        end
    end

    if id == RPC_SCRSETPLAYERPOSFINDZ then
        local pos = {}
		pos.x = bs:readFloat()
		pos.y = bs:readFloat()
		pos.z = bs:readFloat()
    end

    if id == RPC_SCRINTERPOLATECAMERA and not isCoordActive() and not check then
        local set_pos = bs:readBool()
        if set_pos then
            local from_pos = {}
            local dest_pos = {}

            from_pos.x = bs:readFloat()
            from_pos.y = bs:readFloat()
            from_pos.z = bs:readFloat()

            dest_pos.x = bs:readFloat()
            dest_pos.y = bs:readFloat()
            dest_pos.z = bs:readFloat()
            setBotPosition(dest_pos.x, dest_pos.y, dest_pos.z)
            check = true
            newTask(function()
                wait(5000)
                check = false
            end)
        end
    end

    if id == RPC_SCRRESETPLAYERWEAPONS then
        resetWeapons()
		sendWeaponsUpdate()
    end

    if id == RPC_SCRGIVEPLAYERWEAPON then
        addWeapon(bs:readUInt32(), bs:readUInt32())
    end

    if id == RPC_SCRSETPLAYERARMEDWEAPON then
        updateCurrentWeapon(bs:readUInt32())
    end

    if id == RPC_SCRSETPLAYERAMMO then
        setAmmo(bs:readUInt8(), bs:readUInt16())
    end

    if id == RPC_SCRSETSPAWNINFO then
        -- bs:setReadOffset(176)
        -- local weapons, ammo = {}, {}
        -- for i = 1, 3 do weapons[i] = bs:readInt32() end
		-- for i = 1, 3 do ammo[i] = bs:readInt32() end
		-- for i = 3, 1, -1 do
		-- 	if weapons[i] ~= 0 then
		-- 		setAmmo(weapons[i], ammo[i])
		-- 		updateCurrentWeapon(weapons[i])
		-- 	end
		-- end
    end
end)